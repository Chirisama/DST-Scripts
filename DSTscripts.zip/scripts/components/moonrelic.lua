local MoonRelic = Class(function(self, inst)
    self.inst = inst
end)

return MoonRelic
